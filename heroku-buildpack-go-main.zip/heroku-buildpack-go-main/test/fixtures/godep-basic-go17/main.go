package main

import "fmt"
import "runtime"

func main() {
	fmt.Println(runtime.Version())
}
