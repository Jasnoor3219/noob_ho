Structured Logging Helpers

Use the [godoc](http://godoc.org/github.com/heroku/slog)

May evolve into something.

May not.
