package main

import (
	"git.fury.io/go-test-org/gotest"
)

func main() {
	gotest.PrintHello()
}
