package main

import (
	"fmt"

	"gitlab.com/freeformz/private-go-test"
)

func main() {
	fmt.Println("hello")
	fmt.Println(priv.Ate)
}
