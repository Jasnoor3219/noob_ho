package main

import (
	"fmt"
)

func main() {
	fmt.Println("fixture1")
}
