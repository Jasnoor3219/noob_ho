package main

import (
	"fmt"
)

var fixture string

func main() {
	fmt.Println(fixture)
}
