package main

import (
	"fmt"

	"github.com/go-test-user/go-private-repo-test"
)

func main() {
	fmt.Println("hello")
	fmt.Println(priv.Private)
}
