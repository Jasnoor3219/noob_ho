package main

import (
	"fmt"

	"launchpad.net/xmlpath"
)

func main() {
	fmt.Println(xmlpath.Path{})
	fmt.Println("fixture")
}
